#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#!/usr/bin/env python
# coding: utf-8

"""
City -> Pincode Finder (offline, dataset-driven, dependency-free)
--------------------------------------------------------------------
Uses two local CSV files, no internet/API calls, and NO pandas/numpy
dependency.

  1. Indian_Cities_Database.csv  -> City, Lat, Long, country, iso2, State
  2. pincode-dataset.csv         -> Pincode, District, StateName
"""

import csv
import difflib
import os
from collections import defaultdict
from typing import Dict, List, Optional


class PincodeFinder:
    def __init__(self, cities_csv: str, pincodes_csv: str):
        if not os.path.exists(cities_csv):
            raise FileNotFoundError(f"Cities dataset not found: {cities_csv}")
        if not os.path.exists(pincodes_csv):
            raise FileNotFoundError(f"Pincode dataset not found: {pincodes_csv}")

        # --- Load cities dataset ---
        self._cities_by_norm: Dict[str, List[Dict]] = defaultdict(list)
        self._city_names_norm: List[str] = []

        with open(cities_csv, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                name = (row.get("City") or "").strip()
                if not name:
                    continue
                norm = name.lower()
                self._cities_by_norm[norm].append(
                    {
                        "City": name,
                        "State": (row.get("State") or "").strip(),
                        "Lat": (row.get("Lat") or "").strip(),
                        "Long": (row.get("Long") or "").strip(),
                    }
                )
                self._city_names_norm.append(norm)

        # --- Load pincode dataset ---
        self._pins_by_district: Dict[str, List[Dict]] = defaultdict(list)

        with open(pincodes_csv, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                district = (row.get("District") or "").strip()
                pincode = (row.get("Pincode") or "").strip()
                state = (row.get("StateName") or "").strip()
                if not district or not pincode:
                    continue
                norm = district.lower()
                self._pins_by_district[norm].append(
                    {"Pincode": pincode, "District": district, "StateName": state}
                )

    # ---------- internal helpers ----------

    def _suggest_cities(self, query_norm: str, n: int = 5) -> List[str]:
        """Fuzzy 'did you mean' suggestions from both databases."""
        all_names = list(set(self._city_names_norm) | set(self._pins_by_district.keys()))
        close = difflib.get_close_matches(query_norm, all_names, n=n, cutoff=0.5)
        
        seen = set()
        suggestions = []
        for c in close:
            # Check cities db
            for rec in self._cities_by_norm.get(c, []):
                if rec["City"] not in seen:
                    seen.add(rec["City"])
                    suggestions.append(rec["City"])
            # Check pincodes db
            for rec in self._pins_by_district.get(c, []):
                if rec["District"].title() not in seen:
                    seen.add(rec["District"].title())
                    suggestions.append(rec["District"].title())
                    
        return suggestions[:n]

    def _pincodes_for_district(self, district_norm: str, state: Optional[str] = None) -> List[Dict]:
        """Fetches pincodes with smart fallback mechanisms if exact match fails."""
        matches = self._pins_by_district.get(district_norm, [])
        
        # Fallback 1: Substring Match (e.g., "Mumbai" matches "Mumbai Suburban")
        if not matches:
            for d_norm, d_items in self._pins_by_district.items():
                if district_norm in d_norm or d_norm in district_norm:
                    matches.extend(d_items)
                    
        # Fallback 2: Fuzzy Match (Catch slight spelling variations)
        if not matches:
            close = difflib.get_close_matches(district_norm, self._pins_by_district.keys(), n=3, cutoff=0.7)
            for c in close:
                matches.extend(self._pins_by_district[c])

        # Filter by state if applicable
        if state and matches:
            state_norm = state.strip().lower()
            state_matches = [m for m in matches if m["StateName"].strip().lower() == state_norm]
            if state_matches:
                return state_matches
                
        return matches

    # ---------- public API ----------

    def search_cities(self, query: str, limit: int = 10) -> List[Dict]:
        """
        Return the best-matching cities from BOTH datasets.
        """
        query_norm = " ".join(query.strip().split()).lower()
        if not query_norm:
            return []

        scored: List[tuple] = []
        seen = set()

        def add(name_norm: str, score: int) -> None:
            # Search Cities dataset
            for rec in self._cities_by_norm.get(name_norm, []):
                key = (rec["City"], rec["State"])
                if key not in seen:
                    seen.add(key)
                    scored.append((score, rec["City"], rec["State"]))
            
            # Search Pincodes dataset
            for rec in self._pins_by_district.get(name_norm, []):
                key = (rec["District"].title(), rec["StateName"].title())
                if key not in seen:
                    seen.add(key)
                    scored.append((score, key[0], key[1]))

        # Pool all known names together
        all_names = set(self._city_names_norm) | set(self._pins_by_district.keys())

        # 1. Exact Match
        if query_norm in all_names:
            add(query_norm, 0)

        # 2. Prefix & Substring Match
        for name_norm in all_names:
            if name_norm == query_norm:
                continue
            if name_norm.startswith(query_norm):
                add(name_norm, 1)
            elif query_norm in name_norm:
                add(name_norm, 2)

        # 3. Fuzzy Typo Match
        close = difflib.get_close_matches(query_norm, list(all_names), n=limit * 2, cutoff=0.6)
        for name_norm in close:
            add(name_norm, 3)

        scored.sort(key=lambda t: (t[0], t[1]))
        return [{"city": c, "state": s} for _, c, s in scored[:limit]]

    def get_coordinates(self, city_query: str) -> Dict:
        """Look up latitude/longitude for a city."""
        raw = city_query
        query_norm = " ".join(city_query.strip().split()).lower()

        result = {
            "query": raw,
            "found": False,
            "matched_city": None,
            "state": None,
            "latitude": None,
            "longitude": None,
            "suggestions": [],
            "message": "",
        }

        if not query_norm:
            result["message"] = "Please enter a city name."
            return result

        city_records = self._cities_by_norm.get(query_norm, [])
        
        # Smart fallback for coordinates just in case the name was slightly off
        if not city_records:
            close = difflib.get_close_matches(query_norm, self._city_names_norm, n=1, cutoff=0.7)
            if close:
                city_records = self._cities_by_norm.get(close[0], [])

        if not city_records:
            result["suggestions"] = self._suggest_cities(query_norm)
            result["message"] = "Coordinates are only available for the ~213 major cities in Indian_Cities_Database.csv."
            return result

        record = city_records[0]
        try:
            lat = float(record["Lat"]) if record["Lat"] else None
            lon = float(record["Long"]) if record["Long"] else None
        except ValueError:
            lat = lon = None

        if lat is None or lon is None:
            result["message"] = f"'{record['City']}' was found but has no coordinate data."
            return result

        result["found"] = True
        result["matched_city"] = record["City"]
        result["state"] = record["State"] or None
        result["latitude"] = lat
        result["longitude"] = lon
        return result

    def find(self, city_query: str, state: Optional[str] = None) -> Dict:
        """Look up possible pincodes for a city typed by the user."""
        raw = city_query
        query_norm = " ".join(city_query.strip().split()).lower()

        result = {
            "query": raw,
            "matched_city": None,
            "states": [],
            "found": False,
            "pincodes": [],
            "details": [],
            "suggestions": [],
            "message": "",
        }

        if not query_norm:
            result["message"] = "Please enter a city name."
            return result

        # Step 1: Resolve context
        city_records = self._cities_by_norm.get(query_norm, [])
        state_hint = state.strip() if state else None
        canonical_name = raw.strip()

        if city_records:
            if state_hint:
                scoped = [r for r in city_records if r["State"].strip().lower() == state_hint.lower()]
                if scoped:
                    city_records = scoped
            canonical_name = city_records[0]["City"]
            result["matched_city"] = canonical_name
            states_found = sorted({r["State"] for r in city_records if r["State"]})
            result["states"] = states_found
            if not state_hint and len(city_records) == 1:
                state_hint = city_records[0]["State"]

        # Step 2: Look up pincodes by matching District name with smart fallbacks
        pin_matches = self._pincodes_for_district(query_norm, state=state_hint)

        if not pin_matches:
            result["suggestions"] = self._suggest_cities(query_norm)
            result["message"] = f"No matching pincodes were found in the dataset for '{canonical_name}'."
            return result

        details = [
            {"pincode": m["Pincode"], "district": m["District"], "state": m["StateName"]}
            for m in pin_matches
        ]
        unique_pincodes = sorted({d["pincode"] for d in details})

        result["found"] = True
        result["matched_city"] = canonical_name if result["matched_city"] else pin_matches[0]["District"]
        result["states"] = sorted({m["StateName"] for m in pin_matches if m["StateName"]})
        result["pincodes"] = unique_pincodes
        result["details"] = details
        return result


def print_result(result: Dict) -> None:
    print()
    if not result["found"]:
        print(f"No pincodes found for '{result['query']}'.")
        if result["message"]:
            print(result["message"])
        if result["suggestions"]:
            print("Did you mean: " + ", ".join(result["suggestions"]) + "?")
        return

    state_note = f" ({', '.join(result['states'])})" if result["states"] else ""
    print(f"Possible pincodes for '{result['matched_city']}'{state_note}:")
    print(", ".join(result["pincodes"]))

    print("\nDetails:")
    for d in result["details"]:
        print(f"  {d['pincode']}  -  {d['district']}, {d['state']}")


def interactive_lookup(finder: "PincodeFinder") -> None:
    query = input("\nEnter a city name: ").strip()
    if not query:
        print("Please enter a city name.")
        return

    matches = finder.search_cities(query, limit=10)

    if not matches:
        print(f"No matching locations found for '{query}'.")
        result = finder.find(query)
        if result["suggestions"]:
            print("Did you mean: " + ", ".join(result["suggestions"]) + "?")
        return

    print(f"\nFound {len(matches)} matching location(s):")
    for i, m in enumerate(matches, start=1):
        state_note = f" ({m['state']})" if m["state"] else ""
        print(f"  {i}. {m['city']}{state_note}")

    choice = input(f"\nSelect a location [1-{len(matches)}]: ").strip()
    try:
        idx = int(choice) - 1
        if not (0 <= idx < len(matches)):
            raise ValueError
    except ValueError:
        print("Invalid selection.")
        return

    selected_city = matches[idx]["city"]
    selected_state = matches[idx]["state"]
    label = f"{selected_city} ({selected_state})" if selected_state else selected_city
    print(f"\n=== Results for '{label}' ===")

    # 1. Output the Pincodes
    pin_result = finder.find(selected_city, state=selected_state)
    print_result(pin_result)

    # 2. Output the Coordinates
    coord_result = finder.get_coordinates(selected_city)
    print()
    if coord_result["found"]:
        print(f"Coordinates: lat={coord_result['latitude']}, long={coord_result['longitude']}")
    else:
        print(f"Coordinates: {coord_result['message']}")


def _script_dir() -> str:
    try:
        return os.path.dirname(os.path.abspath(__file__))
    except NameError:
        return os.getcwd()


if __name__ == "__main__":
    base_dir = _script_dir()
    
    # Ensure these file names match the actual CSV files on your system
    cities_file = os.path.join(base_dir, "Indian_Cities_Database.csv")
    pincodes_file = os.path.join(base_dir, "pincode-dataset.csv") 
    
    finder = PincodeFinder(cities_file, pincodes_file)
    
    print("Welcome to the Offline City & Pincode Finder!")
    while True:
        interactive_lookup(finder)
        again = input("\nLook up another city? [y/N]: ").strip().lower()
        if again != "y":
            break

